package com.messageapi.dc.dto.response;

import lombok.*;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class ResponseMessages {

    private String id;
}
