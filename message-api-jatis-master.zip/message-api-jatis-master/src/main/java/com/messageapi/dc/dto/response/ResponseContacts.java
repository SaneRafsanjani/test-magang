package com.messageapi.dc.dto.response;

import lombok.*;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter

public class ResponseContacts {

    private String input;

    private String wa_id;
}
